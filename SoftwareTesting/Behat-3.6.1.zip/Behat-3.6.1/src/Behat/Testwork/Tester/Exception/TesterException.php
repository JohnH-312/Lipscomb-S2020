<?php

/*
 * This file is part of the Behat.
 * (c) Konstantin Kudryashov <ever.zet@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Behat\Testwork\Tester\Exception;

/**
 * Represents an exception caused by a tester.
 *
 * @author Konstantin Kudryashov <ever.zet@gmail.com>
 */
interface TesterException
{
}
