/**
 * @fileoverview Externs for Storage.
 * @externs
 */

var BlocklyStorage = {};
