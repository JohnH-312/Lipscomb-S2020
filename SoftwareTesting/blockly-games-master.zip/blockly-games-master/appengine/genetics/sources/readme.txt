Broken Heart:
* Broken_heart.svg -- original file used for broken heart
created by:
https://commons.wikimedia.org/wiki/File:Broken_heart.svg

Heart:
* heart.xcf -- A Gimp file containing the different full heart
variations. Original graphic Heart.svg created by:
https://commons.wikimedia.org/wiki/File:Heart_coraz%C3%B3n.svg